import markdown2
import random
import re
from django.shortcuts import render, redirect
from django.http import  HttpResponse

from . import util



# default page


def index(request):
    return render(request, "encyclopedia/index.html", {
        "entries": util.list_entries()
    })



def wiki(request, title):
    pagelist = util.list_entries()

    if title in pagelist:
        content = util.get_entry(title)

        return render(request, "encyclopedia/content.html", {
            "title": title,
            "content": markdown2.markdown(content)
        })
    else:
        return render(request, "encyclopedia/error.html", {
            'error_message': 'Page can\'t be found'
        })



def random_page(request):
    pagelist=util.list_entries()
    # random no. in [0-len[pagelist]-1]]
    random_no = random.randint(0, len(pagelist)-1)
    title = pagelist[random_no]

    return redirect(wiki, title=title)  




def search(request):
    pagelist=util.list_entries()
    if request.method == 'POST':
        term = request.POST
        term = term['q']
        searchlist = []

        for page in pagelist:

            if re.search(term.lower(), page.lower()):  
                searchlist.append(page)
        if len(searchlist) == 0: 
            return render(request, "encyclopedia/error.html", {
                'error_message': f'No results found for \'{term}\' '
            })

    return render(request, "encyclopedia/search.html", {
        'entries': searchlist
    })



def add_page(request):
    pagelist=util.list_entries()
    if request.method == 'POST':
        title = request.POST.get('title')
        content = request.POST.get('content')
        if title in pagelist:
            return render(request, "encyclopedia/add_content.html", {
                'available': False
            })
        else:
            util.save_entry(title, content)
            return redirect(wiki, title=title)
    return render(request, "encyclopedia/add_content.html", {
        'available': True
    })



def edit_page(request, title):
    pagelist=util.list_entries()
    content = util.get_entry(title)
    if request.method == 'GET':
        return render(request, "encyclopedia/edit.html", {
            'title': title,
            'content': content
        })
    if request.method == 'POST':
        content = request.POST.get('newcontent')
        util.save_entry(title, content)
        return redirect(wiki, title=title)